import React from 'react'

export default function SecureRoutes() {
  return (
    <div>
      
    </div>
  )
}
