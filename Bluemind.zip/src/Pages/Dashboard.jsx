import React from "react";

export default function Dashboard() {
  return (
    <div className="dark:bg-background-dark bg-background-light  min-h-[calc(100vh-1px)]"></div>
  );
}
