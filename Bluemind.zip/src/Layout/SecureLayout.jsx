import React from 'react'

export default function SecureLayout() {
  return (
    <div>
      
    </div>
  )
}
