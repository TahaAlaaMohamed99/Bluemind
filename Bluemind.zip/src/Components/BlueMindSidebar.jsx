import React, { useState } from "react";
import { TrendingUp, ChevronRight, ChevronDown } from "lucide-react";
import logo from "../Assets/Logo.svg";
import { NavLink, useLocation } from "react-router-dom";
import {
  IconBanking,
  IconCommerce,
  IconCommunity,
  IconConstruction,
  IconDashboard,
  IconDocumentation,
  IconEducation,
  IconFraud,
  IconHelpAndCenter,
  IconMedia,
  IconRealState,
  IconRestaurant,
  IconSales,
} from "../Assets/Icons/IconsSvg";

const BlueMindSidebar = ({ isCollapsed, setIsCollapsed }) => {
  const [expandedItems, setExpandedItems] = useState({});
  const location = useLocation();

  const sidebarData = [
    {
      id: "dashboard",
      title: "Dashboard",
      icon: IconDashboard,
      route: "/",
      type: "single",
    },
    {
      id: "workSpace",
      title: "Work Space",
      icon: TrendingUp,
      type: "single",
      route: "/workspace",
    },
    { id: "subscription", title: "SUBSCRIPTION", type: "header" },
    {
      id: "media",
      title: "Media",
      icon: IconMedia,
      type: "single",
      route: "/mediaMonitoring/Add",
    },

    {
      id: "real-estate",
      title: "Real Estate",
      icon: IconRealState,
      type: "single",
      route: "/real-estate/Add",
    },
    {
      id: "restaurant",
      title: "Restaurant",
      icon: IconRestaurant,
      type: "single",
      route: "/restaurant/Add",
    },
    {
      id: "education",
      title: "Education",
      icon: IconEducation,
      type: "single",
      route: "/education/Add",
    },
    {
      id: "sales",
      title: "Sales",
      icon: IconSales,
      type: "single",
      route: "/sales/Add",
    },
    {
      id: "concrete",
      title: "Concrete",
      icon: TrendingUp,
      type: "single",
      route: "/concrete/Add",
    },
    {
      id: "textAnalysis",
      title: "Text Analysis",
      icon: TrendingUp,
      type: "single",
      route: "/textAnalysis/Add",
    },
    {
      id: "fraud",
      title: "Fraud",
      icon: IconFraud,
      type: "expandable",
      children: [
        {
          id: "fraud-detection",
          title: "Fraud Detection",
          route: "/fraud/detection",
        },
      ],
    },
    {
      id: "commerce",
      title: "Commerce",
      icon: IconCommerce,
      type: "expandable",
      children: [
        {
          id: "product-analysis",
          title: "Product Analysis",
          route: "/commerce/products",
        },
      ],
    },
    {
      id: "construction",
      title: "Construction",
      icon: IconConstruction,
      type: "expandable",
      children: [
        {
          id: "project-monitoring",
          title: "Project Monitoring",
          route: "/construction/projects",
        },
      ],
    },
    {
      id: "banking",
      title: "Banking",
      icon: IconBanking,
      type: "single",
      route: "/banking",
    },
    { id: "support", title: "SUPPORT", type: "header" },
    {
      id: "documentation",
      title: "Documentation",
      icon: IconDocumentation,
      type: "single",
      route: "/documentation",
    },
    {
      id: "community",
      title: "Community",
      icon: IconCommunity,
      type: "single",
      route: "/community",
    },
    {
      id: "help-support",
      title: "Help & Support",
      icon: IconHelpAndCenter,
      type: "single",
      route: "/help",
    },
  ];

  const toggleExpanded = (itemId) =>
    setExpandedItems((prev) => ({ ...prev, [itemId]: !prev[itemId] }));

  const isRouteActive = (route) =>
    location.pathname === route || location.pathname.startsWith(route + "/");

  const renderIcon = (IconComponent, isActive = false) =>
    IconComponent ? (
      <IconComponent
        className={`sidebar-icon ${isActive ? "text-primary" : ""}`}
      />
    ) : null;

  const renderChildren = (children, parentId, level = 1) => (
    <div className={`sidebar-children level-${level}`}>
      {children.map((child) => {
        const hasGrandChildren =
          Array.isArray(child.children) && child.children.length > 0;

        if (hasGrandChildren) {
          const isExpanded = expandedItems[child.id];
          const hasActiveDescendant =
            child.children?.some((c) => isRouteActive(c.route)) ||
            isRouteActive(child.route || "");

          return (
            <div key={child.id} className="sidebar-child">
              <div
                className={`sidebar-item ${
                  hasActiveDescendant
                    ? "bg-primary text-white dark:bg-primary dark:text-white"
                    : "hover:bg-gray-100 dark:hover:bg-background-cardDark"
                }`}
                onClick={() => toggleExpanded(child.id)}
              >
                <div className="sidebar-item-content">
                  <span className="sidebar-title">{child.title}</span>
                  <span className="sidebar-arrow">
                    {isExpanded ? <ChevronDown /> : <ChevronRight />}
                  </span>
                </div>
              </div>
              {isExpanded &&
                renderChildren(child.children, child.id, level + 1)}
            </div>
          );
        }

        return (
          <NavLink
            key={child.id}
            to={child.route}
            className={({ isActive }) =>
              `sidebar-item  ${
                isActive
                  ? "bg-white text-primary  "
                  : "hover:bg-gray-100 dark:hover:bg-background-cardDark"
              }`
            }
          >
            {({ isActive }) => (
              <div
                className={`sidebar-item-content ${isActive && "text-primary"}`}
              >
                <span className="sidebar-title">{child.title}</span>
              </div>
            )}
          </NavLink>
        );
      })}
    </div>
  );

  return (
    <div className={`sidebar  bg-background-light dark:bg-background-dark`}>
      <div className="sidebar-header  border-border-light dark:border-border-dark">
        <div className="sidebar-logo">
          <img src={logo} alt="sidebar-logo" />
        </div>
      </div>

      <div className="sidebar-content text-textColor-light dark:text-titleColor-dark">
        {sidebarData.map((item) => {
          if (item.type === "header") {
            return (
              <div
                key={item.id}
                className="sidebar-header-text text-xs font-semibold text-gray-500 dark:text-textColor-dark mt-4 mb-2"
              >
                {item.title}
              </div>
            );
          }

          if (item.type === "single") {
            return (
              <NavLink
                key={item.id}
                to={item.route}
                className={({ isActive }) =>
                  `sidebar-item flex items-center p-3 rounded-md transition-colors 
                   ${
                     isActive
                       ? "bg-white text-primary dark:bg-background-cardDark dark:text-white"
                       : "hover:bg-gray-100 dark:hover:bg-background-cardDark"
                   } 
                   text-textColor-light dark:text-titleColor-dark`
                }
              >
                {({ isActive }) => (
                  <>
                    {renderIcon(item.icon, isActive)}
                    <span className={`ml-4`}>{item.title}</span>
                  </>
                )}
              </NavLink>
            );
          }

          if (item.type === "expandable") {
            const isExpanded = expandedItems[item.id];
            const hasActiveChild =
              item.children?.some((child) => isRouteActive(child.route)) ||
              false;

            return (
              <div key={item.id} className="sidebar-expandable">
                <div
                  className={`sidebar-item flex items-center px-3 py-2 rounded-md transition-colors cursor-pointer
                  ${
                    hasActiveChild
                      ? "bg-primary text-white dark:bg-primary dark:text-white"
                      : "hover:bg-gray-100 dark:hover:bg-background-cardDark"
                  } 
                  text-textColor-light dark:text-titleColor-dark`}
                  onClick={() => toggleExpanded(item.id)}
                >
                  {renderIcon(item.icon, hasActiveChild)}
                  <span className="ml-2 flex-1">{item.title}</span>
                  <span className="sidebar-arrow">
                    {isExpanded ? <ChevronDown /> : <ChevronRight />}
                  </span>
                </div>
                {isExpanded && renderChildren(item.children, item.id)}
              </div>
            );
          }

          return null;
        })}
      </div>
    </div>
  );
};

export default BlueMindSidebar;
